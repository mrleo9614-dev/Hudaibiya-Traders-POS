# Hudaibiya Traders POS — Android Test Project

This is an Android Studio project source package, not a prebuilt APK.

## Build a test APK
1. Install Android Studio on a computer.
2. Open this folder (`HudaibiyaTradersAndroid`) in Android Studio.
3. Let Gradle sync complete. Install Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location, usually:
   `app/build/outputs/apk/debug/app-debug.apk`

## Included prototype
- Android WebView wrapper with offline local assets
- Existing POS prototype UI and local browser storage
- Product stock tracked in pieces with dozen conversion
- Sales, purchases, customer records, partial payments and invoice preview
- Invoice print page set to 7.5 × 10 inches, 300 DPI print resolution requested

## Important
- This is a test build source project. It has not been compiled or device-tested here.
- Cloud sync is not yet connected. Data remains local to this app installation.
- Confirm actual printer paper support and margins before commercial printing.
- The current invoice is an implementation preview; verify all branding, address spelling, phone numbers and calculations before using for real customer transactions.
